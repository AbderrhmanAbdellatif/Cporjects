#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h> 
#include <string.h> 
#include "kupa.h"
#include <ctype.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
char * takimlarOku(char * adress) {

	 char *takimlar[36];

	char str[32];

	if (takimlar == NULL)
	{
		fprintf(stderr, "Out of memory (1).\n");
		exit(1);
	}
	FILE *fPtr;
	fPtr = fopen("takimlar.txt", "r");

	if (fPtr == NULL) {
		puts("Hata: Dosya acilamadi!");
		exit(1);
	}
	else {

		puts("Dosya basariyla acildi");
	}
	int j, i = 0;


	while (fgets(str, 32, fPtr)) {
		takimlar[i] = (char *)malloc(100 * sizeof(char));
		strcpy(takimlar[i], str);
		printf(takimlar[i]);
		i++;

	}
	fclose(fPtr);




	return  &(takimlar[0]);
}

//https://stackoverflow.com/questions/4085372/how-to-return-a-string-array-from-a-function



/*char ** karistirDiz (char *takimlar){
char 	groupDizi[8][4];
srand(time(NULL));
int varmi = 0;
int i ;int j;int k;
for( i =0 ; i<8 ; i++){
for( j=0 ; j <4 ; j++){
int random_number = rand() % 8 + 1;

for( k =0 ; k<4 ; k++){
if(groupDizi[i][j]==takimlar[random_number])
varmi = 1;
}
if(!varmi){
groupDizi[i][j]==takimlar[random_number];
}


}
}

groupDizi;

}*/

/*char * sirala(char ** takimlar){
int i , j ;
char grouplar[8][4] ={"ef","", "fesfS"};

return grouplar;
}*/







