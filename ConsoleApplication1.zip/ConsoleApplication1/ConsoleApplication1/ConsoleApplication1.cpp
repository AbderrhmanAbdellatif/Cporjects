// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include "kupa.h"

int main(int argc, char *argv[]) {
	printf("grimedi");
	int i = 0;
	char **takimla =takimlarOku("takimlar.txt");
	for (size_t i = 0; i < 40; i++)
	{
		printf("*(p + %s) : %d\n", i, **(takimla + i));

	}
	printf("cikti");


	system("pause");
	return 0;
}
