#pragma once
#include <stdio.h>
#include <stdlib.h>

char ** takimlarOku(char * adress);
char ** print(char * adress);
char ** karistirDiz(char * takimlar);
//char * sirala(char ** takimlar);

