#include <stdio.h>

#define A 'A'

int main(){
    char ch;
    ch=A;
    printf("Output is %c", ch);
    return 1;
}
