#include<stdio.h>

const int* ptr;

int main(void)
{
    int var1 = 0;
    const int *ptr = &var1;
    *ptr = 1;
    printf("%d\n", *ptr);

    return 0;
}

