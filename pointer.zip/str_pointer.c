#include<stdio.h>
#include <string.h>
int findLength(char *p);
void findLength2(char *p, int *c);

int main(void)
{
	int i=0;
	int length[4];
	int cnt = 0;
	char *suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };
	
	for(i=0;i<4;i++)
	{
		length[i] = findLength(suit[i]);
		printf("length( %s ) = %d \n",suit[i],length[i]);
	}
	printf("\n version 2\n");
	
	for(i=0;i<4;i++)
	{
		findLength2(suit[i], &length[i]);
		printf("length( %s ) = %d \n",suit[i],length[i]);
	}
	
}
int findLength(char *p)
{
    int c=0;
    while(*p!='\0')
    {
        c++;
        *p++;
    }
    return(c);
}

void findLength2(char *p, int *c)
{
    *c=0;
    while(*p!='\0')
    {
        (*c)++;
        *p++;
    }

}
