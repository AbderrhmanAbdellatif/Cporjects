
#include <stdio.h>

void swap(int a, int b){
   	int temp = a;
   	a = b;
	b=temp;
}

void swapPtr(int *ptr1, int *ptr2){
  int temp = *ptr1;
  *ptr1 = *ptr2;
  *ptr2 = temp;
}
int main (void){
    int x = 5, y = 3;
    printf("before swapping x=%d y=%d\n", x, y);
    swap(x,y);
    printf("after swapping - call by value x=%d y=%d\n", x, y);
	swapPtr(&x,&y);
    printf("after swapping - call by reference x=%d y=%d\n", x, y);
    
	return 0;
}

