#include<stdio.h>

int main(void)
{
    int b[4]= {0,1,2,3};
	int i;
	
   	for ( i = 0; i < 4; i++ ) {
		printf( "b[ %d ] = %d\n", i, b[ i ] );
   	} /* end for */
	printf("\nPointer ile gezinme\n");
	//Diziyi pointer ile gezmek
   	int *ptr;
   	ptr=b;
   	for ( i = 0; i < 4; i++ ) {
		printf( "b[ %d ] = %d\n", i, *ptr++ );
   	} /* end for */
   	
   	printf("\nPointer ile gezinme 2\n");
   	ptr=&b[0];
   	for ( i = 0; i < 4; i++ ) {
		printf( "b[ %d ] = %d\n", i, *ptr++ );
   	} /* end for */
}
