#include <stdio.h>
#define SIZE 10

// prototypes
int ascending(int a, int b);
int descending(int a, int b);
int (*compare)(int a, int b);

int main(void)
{
	int a = 4, b = 5;
	compare = ascending;
	printf("compare - ascending %d \n",compare(a,b));
	
	compare = descending;
	printf("compare - descending %d \n",compare(a,b));
	
}

// determine whether elements are out of order for an ascending
// order sort                                               
int ascending(int a, int b)                                  
{                                                              
   return b < a; // should swap if b is less than a         
}

// determine whether elements are out of order for a descending
// order sort                                               
int descending(int a, int b)                                 
{                                                              
   return b > a; // should swap if b is greater than a      
}

