
#include <stdio.h>


int main()
{ 
	int x,y; 
 	int *ptr;
	y=5;
	ptr=&y; 

	printf("icerik: %d %d\n", y,*ptr);
	printf("adres : %p adres %p\n", &y,ptr);
	
	printf("\n &*ptr = %p , *&ptr = %p\n", &*ptr,*&ptr);
	return 0;
}
