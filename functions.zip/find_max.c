#include <stdio.h>

#define max(A,B) (((A)>(B))?(A):(B))

int main(){
	int a = 5, b= 7, c= 4;
 	int temp, result;
 
  	temp=max(a,b);
	result=max(temp,c);
	printf("max(%d, %d, %d) =  %d \n",a,b,c,result);
	return 0;
}

