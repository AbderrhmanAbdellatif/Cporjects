#include <stdio.h>
void fark (void)
{
  static int deger;
  int yeni_deger;
  printf("bir deger giriniz\n");
  scanf("%d", &yeni_deger);
  printf("Bu deger son seferden (eski deger=%d) %d birim farklidir.\n", deger, deger - yeni_deger);
  deger = yeni_deger;
}

int main()
{  
	fark();
	fark();
}

